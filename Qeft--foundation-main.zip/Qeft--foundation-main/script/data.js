$(document).ready(function () {
    $.ajax({
          url: 'process.php',
          type: 'POST',
          data: {
            action: 'DisplayAllData',
            id: $('#cityID').val()
          },
          success: function (response) {
            $('#DisplayDataPage_table').html(response);
          }
        });








        $.ajax({
            url: 'process.php',
            type: 'POST',
            data: {
              action: 'DisplayAllData_PRINT',
              id: $('#cityID').val()
            },
            success: function (response) {
              $('#DisplayDataPage_table_print').html(response);
            }
          });





          $('#ExcelBtn').click(function() {
            $.ajax({
              url: 'excelFile.php',
              type: 'POST',
              data: {
                action: 'printExcel'              },
              success: function (response) {
                
              }
            });
          });

    });