$(document).ready(function () {



    $('.mainTable-data-tr').click(function() {
        // Find the radio button inside the clicked tr and select it
        $(this).find('input[type="radio"]').prop('checked', true);

        var personID = '';

        personID = $(this).find('input[type="radio"]').val();
        // console.log($(this).find('input[type="radio"]').val());

        $.ajax({
            url: 'process.php',
            type: 'POST',
            data: {
              action: 'DisplayStatusPaper',
              id: personID
            },
            success: function (response) {
              $('#statusPaperData').html('response');
            }
          });
    });
    
    
    $('.statusPaperPagePID').click(function() {
        var personID = '';

        personID = $(this).val();



        $.ajax({
            url: 'process.php',
            type: 'POST',
            data: {
              action: 'DisplayStatusPaper',
              id: personID
            },
            success: function (response) {
              $('#statusPaperData').html('response');
            }
          });
    });







    $.ajax({
      url: 'process.php',
      type: 'POST',
      data: {
        action: 'DisplayAllStatusData'
      },
      success: function (response) {
        $('#StatusDataTable').html(response);
      }
    });

    });


