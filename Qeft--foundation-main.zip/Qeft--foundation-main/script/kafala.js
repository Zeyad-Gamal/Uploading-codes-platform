$(document).ready(function () {
    $.ajax({
          url: 'process.php',
          type: 'POST',
          data: {
            action: 'DisplayAllKafalaData'
          },
          success: function (response) {
            $('#papersContainer').html(response);
          }
        });
    });