$(document).ready(function () {

    $.ajax({
          url: 'process.php',
          type: 'POST',
          data: {
            action: 'DisplayAllCities'
          },
          success: function (response) {
            $('#DisplayCitiesContainer').html(response);
          }
        });


});