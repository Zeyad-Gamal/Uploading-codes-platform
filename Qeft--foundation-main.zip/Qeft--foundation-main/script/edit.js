
$(document).ready(function() {
    $('#addPerson').click(function() {
        

        if(ValiFlag == 'no'){
            return;
        }

        var messageC = '';
        messageC = `<div id="addPersonMessage" class="alert alert-success" role="alert" style="position: relative;top: 3rem;display: flex;align-items: center;">
                <div class="spinner-border text-success" role="status">
                    <span class="visually-hidden">Loading...</span>
                  </div>&nbsp; جاري التحميل
              </div>`;
        $('#MessageContainer').html(messageC);


        // messageC = `تم إضافة البيانات بنجاح`;
        
        // $('#addPersonMessage').html(messageC);
        
        
        
        var FormDataP = new FormData($('#newPersonData')[0]);
        var action = "addNewPerson";

        FormDataP.append("action",action);

       


            $.ajax({
                url: 'process.php',
                type: 'POST',
                data:FormDataP,
                processData:false,
                contentType:false,
                success: function(response){
              $('#addPersonMessage').html(response);
              $('#newPersonData').trigger("reset");
                },
    
                
            });
        
    });






    var personID = '';

    $('.mainTable-data-tr').click(function() {
    // Find the radio button inside the clicked tr and select it
        $(this).find('input[type="radio"]').prop('checked', true);


        personID = $(this).find('input[type="radio"]').val();
        // console.log($(this).find('input[type="radio"]').val());
        $('#updateModalbutton').show();
        $('#deleteModalbutton').show();
        $('#addPerson').hide();

    
    });

    

    // $('#updateModalbutton').click(function() {
    //     console.log(validation);
    //     if (validation!==5) {
    //         $('#updateModalbutton').attr('data-bs-target', '#');
    //         return;
    //     }else{
    //         $('#updateModalbutton').attr('data-bs-target', '#updateModal');
    //     }
    // });
    
    
    

    $('#updatePerson').click(function() {
        
        

           
        var messageC = '';
        messageC = `<div class="spinner-border text-dark" role="status">
                    <span class="visually-hidden">Loading...</span>
                  </div>&nbsp; جاري التحميل`;
        $('#updateMessageContainer').html(messageC);

       
        
        
        var FormDataP = new FormData($('#newPersonData')[0]);
        var action = "updatePerson";

        FormDataP.append("action",action);
        FormDataP.append("pid",personID);

       


            $.ajax({
                url: 'process.php',
                type: 'POST',
                data:FormDataP,
                processData:false,
                contentType:false,
                success: function(response){
              $('#updateMessageContainer').html('');        
              $('#updateModal .btn-close').click();

              messageC = `<div id="updatePersonMessage" class="alert alert-warning" role="alert" style="position: relative;top: 3rem;display: flex;align-items: center;">
              تم تحديث البيانات بنجـاح
            </div>`;
      $('#MessageContainer').html(messageC);
      $('#newPersonData').trigger("reset");
                },
    
                
            });




    });
   


    $('#deletePerson').click(function() {
        
        

           
        var messageC = '';
        messageC = `<div class="spinner-border text-danger" role="status">
                    <span class="visually-hidden">Loading...</span>
                  </div>&nbsp; جاري التحميل`;
        $('#deleteMessageContainer').html(messageC);

       
        
        
        var FormDataP = new FormData($('#newPersonData')[0]);
        var action = "deletePerson";

        FormDataP.append("action",action);
        FormDataP.append("pid",personID);

       


            $.ajax({
                url: 'process.php',
                type: 'POST',
                data:FormDataP,
                processData:false,
                contentType:false,
                success: function(response){
              $('#deleteMessageContainer').html('');        
              $('#deleteModal .btn-close').click();

              messageC = `<div id="updatePersonMessage" class="alert alert-danger" role="alert" style="position: relative;top: 3rem;display: flex;align-items: center;">
              تم حذف البيانات بنجـاح
            </div>`;
      $('#MessageContainer').html(messageC);
      $('#newPersonData').trigger("reset");
                },
    
                
            });




    });


});

